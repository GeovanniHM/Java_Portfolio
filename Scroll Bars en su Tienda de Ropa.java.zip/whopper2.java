import javax.swing.*;
import java.awt.event.*;
import java.awt.*;

public class whopper2 extends JFrame implements ItemListener , ActionListener{

public JLabel Pantalon;
public JLabel Camisa;
public JLabel Calceta;
public JLabel Genero;
public JLabel Edad;
public JComboBox <String> Pcolor;
public JComboBox <String> Ptalla;
public JComboBox <String> Pcorte;
public JComboBox <String> Ccolor;
public JComboBox <String> Cmanga;
public JComboBox <String> CCalceta;
public JComboBox <String> GGenero;
public JComboBox <String> EEdad;
public JTextArea areadetexo;
public String Inf;
public JButton confirmacion;
public JScrollPane scroll;

public whopper2(){


setLayout(null);
setDefaultCloseOperation(EXIT_ON_CLOSE);
getContentPane().setBackground(new Color(100,180,100));
setTitle("Combo whopper");

Pantalon = new JLabel("Pantalon");
Pantalon.setBounds(30,50,80,20);
Pantalon.setForeground(Color.RED);
add(Pantalon);

Camisa = new JLabel("Camisa");
Camisa.setBounds(30,70,80,20);
Camisa.setForeground(Color.RED);
add(Camisa);

Calceta = new JLabel("Calceta");
Calceta.setBounds(30,90,80,20);
Calceta.setForeground(Color.RED);
add(Calceta);

Genero = new JLabel("Genero");
Genero.setBounds(30,110,80,20);
Genero.setForeground(Color.RED);
add(Genero);

Edad = new JLabel("Edad");
Edad.setBounds(30,130,50,20);
Edad.setForeground(Color.RED);
add(Edad);

Pcolor = new JComboBox();
Pcolor.setBounds(100,50,80,20);
add(Pcolor);
Pcolor.setForeground(Color.BLUE);

Pcolor.addItem("ROJO");
Pcolor.addItem("VERDE");
Pcolor.addItem("CAFE");
Pcolor.addItem("GRIS");
Pcolor.addItem("NEGRO");

Ptalla= new JComboBox();
Ptalla.setBounds(200,50,80,20);
add(Ptalla);
Ptalla.setForeground(Color.BLUE);

Ptalla.addItem("CH");
Ptalla.addItem("M");
Ptalla.addItem("X");
Ptalla.addItem("XL");
Ptalla.addItem("XX");
Ptalla.addItem("XXL");

Pcorte = new JComboBox();
Pcorte.setBounds(300,50,80,20);
add(Pcorte);
Pcorte.setForeground(Color.BLUE);

Pcorte.addItem("Amplio");
Pcorte.addItem("Relajado");
Pcorte.addItem("Recto");
Pcorte.addItem("Slim");
Pcorte.addItem("Slim Fit");
Pcorte.addItem("Skinny");

Ccolor = new JComboBox();
Ccolor.setBounds(100,70,80,20);
add(Ccolor);
Ccolor.setForeground(Color.BLUE);

Ccolor.addItem("ROJO");
Ccolor.addItem("VERDE");
Ccolor.addItem("CAFE");
Ccolor.addItem("GRIS");
Ccolor.addItem("NEGRO");

Cmanga = new JComboBox();
Cmanga.setBounds(200,70,80,20);
add(Cmanga);
Cmanga.setForeground(Color.BLUE);

Cmanga.addItem("Larga");
Cmanga.addItem("Corta");
Cmanga.addItem("Nada");


CCalceta = new JComboBox();
CCalceta.setBounds(100,90,80,20);
add(CCalceta);
CCalceta.setForeground(Color.BLUE);

CCalceta.addItem("Dama");
CCalceta.addItem("Caballero");
CCalceta.addItem("Indefinido");


GGenero = new JComboBox();
GGenero.setBounds(100,110,80,20);
add(GGenero);
GGenero.setForeground(Color.BLUE);

GGenero.addItem("Dama");
GGenero.addItem("Caballero");
GGenero.addItem("Indefinido");

EEdad = new JComboBox();
EEdad.setBounds(100,130,80,20);
add(EEdad);
EEdad.setForeground(Color.BLUE);

EEdad.addItem("1-5");
EEdad.addItem("6-10");
EEdad.addItem("11-15");
EEdad.addItem("16-20");
EEdad.addItem("21-25");
EEdad.addItem("26-30");

confirmacion = new JButton("Confirmar");
confirmacion.setBounds(100,150,200,20);
add(confirmacion);

areadetexo = new JTextArea("");
areadetexo.setBounds(30,200,400,150);
areadetexo.setEditable(false);
add(areadetexo);

scroll = new JScrollPane(areadetexo);
scroll.setBounds(30,200,400,160);
add(scroll);

confirmacion.addActionListener(this);
Pcolor.addItemListener(this);
Ptalla.addItemListener(this);
Pcorte.addItemListener(this);
Ccolor.addItemListener(this);
Cmanga.addItemListener(this);
CCalceta.addItemListener(this);
GGenero.addItemListener(this);
EEdad.addItemListener(this);
}

public void itemStateChanged(ItemEvent accion){

}

public void actionPerformed(ActionEvent accion){

if(accion.getSource() == confirmacion){

Inf = "Pantalon: \n" + Pcolor.getSelectedItem().toString() + "\n" + Ptalla.getSelectedItem().toString() + "\n" + Pcorte.getSelectedItem().toString() + "\n" + "Camisa: \n" + Ccolor.getSelectedItem().toString() + "\n" + Cmanga.getSelectedItem().toString() + "\n" + "Calceta: \n" + CCalceta.getSelectedItem().toString() + "\n" + "Genero: \n" + GGenero.getSelectedItem().toString() + "\n" + 
"Edad: \n" + EEdad.getSelectedItem().toString();

areadetexo.setText(Inf);

}
}

public static void main(String args[]){
        
whopper2 combowhopperJr = new whopper2();
combowhopperJr.setBounds(0, 100, 500, 450);
combowhopperJr.setVisible(true);
combowhopperJr.setResizable(false);
        
}
}