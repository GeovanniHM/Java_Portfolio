import javax.swing.*;
import java.awt.event.*;
import java.awt.*;

public class CASIO30 extends JFrame implements ActionListener{


public JButton boton1;
public JButton boton2;
public JButton boton3;
public JButton boton4;
public JButton boton5;
public JButton boton6;
public JButton boton7;
public JButton boton8;
public JButton boton9;
public JButton boton0;
public JButton botonSuma;
public JButton botonResta;
public JButton botonDivision;
public JButton botonMultiplicacion;
public JButton botonIgual;
public JButton botonCE;
public JButton botonCerrar;
public JTextField campoDeTexto;
public String  memoria1;
public String  memoria2;
public String signo;

public CASIO30(){

setLayout(null);
setTitle("Calculadora WINDOWS");
getContentPane().setBackground(new Color(0,0,0));
setDefaultCloseOperation(EXIT_ON_CLOSE);

campoDeTexto = new JTextField();
campoDeTexto.setBounds(50, 25, 200, 30);
add(campoDeTexto);

boton1 = new JButton("1");
boton1.setBounds(50, 50, 50, 50);
boton1.setForeground(Color.BLUE);
add(boton1);

boton2 = new JButton("2");
boton2.setBounds(100, 50, 50, 50);
boton2.setForeground(Color.BLUE);
add(boton2);

boton3 = new JButton("3");
boton3.setBounds(150, 50, 50, 50);
boton3.setForeground(Color.BLUE);
add(boton3);

botonSuma = new JButton("+");
botonSuma.setBounds(200, 50, 50, 50);
botonSuma.setForeground(Color.BLUE);
add(botonSuma);

boton4 = new JButton("4");
boton4.setBounds(50, 100, 50, 50);
boton4.setForeground(Color.BLUE);
add(boton4);

boton5 = new JButton("5");
boton5.setBounds(100, 100, 50, 50);
boton5.setForeground(Color.BLUE);
add(boton5);

boton6 = new JButton("6");
boton6.setBounds(150, 100, 50, 50);
boton6.setForeground(Color.BLUE);
add(boton6);

botonResta = new JButton("-");
botonResta.setBounds(200, 100, 50, 50);
botonResta.setForeground(Color.BLUE);
add(botonResta);

boton7 = new JButton("7");
boton7.setBounds(50, 150, 50, 50);
boton7.setForeground(Color.BLUE);
add(boton7);

boton8 = new JButton("8");
boton8.setBounds(100, 150, 50, 50);
boton8.setForeground(Color.BLUE);
add(boton8);

boton9 = new JButton("9");
boton9.setBounds(150, 150, 50, 50);
boton9.setForeground(Color.BLUE);
add(boton9);

botonDivision = new JButton("/");
botonDivision.setBounds(200, 150, 50, 50);
botonDivision.setForeground(Color.BLUE);
add(botonDivision);

boton0 = new JButton("0");
boton0.setBounds(100, 200, 50, 50);
boton0.setForeground(Color.BLUE);
add(boton0);

botonCE = new JButton("CE");
botonCE.setBounds(150, 200, 50, 50);
botonCE.setForeground(Color.BLUE);
add(botonCE);

botonMultiplicacion = new JButton("x");
botonMultiplicacion.setBounds(200, 200, 50, 50);
botonMultiplicacion.setForeground(Color.BLUE);
add(botonMultiplicacion);

botonIgual = new JButton("=");
botonIgual.setBounds(50, 200, 50, 50);
botonIgual.setForeground(Color.BLUE);
add(botonIgual);

botonCerrar = new JButton("close");
botonCerrar.setBounds(110, 250, 80, 50);
botonCerrar.setForeground(Color.BLUE);
add(botonCerrar);

boton1.addActionListener(this);
boton2.addActionListener(this);
boton3.addActionListener(this);
botonSuma.addActionListener(this);
boton4.addActionListener(this);
boton5.addActionListener(this);
boton6.addActionListener(this);
botonResta.addActionListener(this);
boton7.addActionListener(this);
boton8.addActionListener(this);
boton9.addActionListener(this);
botonDivision.addActionListener(this);
boton0.addActionListener(this);
botonCE.addActionListener(this);
botonMultiplicacion.addActionListener(this);
botonIgual.addActionListener(this);
botonCerrar.addActionListener(this);
}


public void actionPerformed(ActionEvent accion){
if(accion.getSource() == botonCerrar){
System.exit(0);
}
if(accion.getSource() == boton1){
campoDeTexto.setText(campoDeTexto.getText()+"1");
}
if(accion.getSource() == boton2){
campoDeTexto.setText(campoDeTexto.getText()+"2");
}
if(accion.getSource() == boton3){
campoDeTexto.setText(campoDeTexto.getText()+"3");
}
if(accion.getSource() == boton4){
campoDeTexto.setText(campoDeTexto.getText()+"4");
}
if(accion.getSource() == boton5){
campoDeTexto.setText(campoDeTexto.getText()+"5");
}
if(accion.getSource() == boton6){
campoDeTexto.setText(campoDeTexto.getText()+"6");
}
if(accion.getSource() == boton7){
campoDeTexto.setText(campoDeTexto.getText()+"7");
}
if(accion.getSource() == boton8){
campoDeTexto.setText(campoDeTexto.getText()+"8");
}
if(accion.getSource() == boton9){
campoDeTexto.setText(campoDeTexto.getText()+"9");
}
if(accion.getSource() == boton0){
campoDeTexto.setText(campoDeTexto.getText()+"0");
}
if(accion.getSource()== botonCE){
campoDeTexto.setText("");
}
if(accion.getSource() == botonSuma){
if(!campoDeTexto.getText().equals("")){
signo = "+";
memoria1 = campoDeTexto.getText();
campoDeTexto.setText("");
}
}
if(accion.getSource()== botonResta){
if(!campoDeTexto.getText().equals("")){
signo = "-";
memoria1 = campoDeTexto.getText();
campoDeTexto.setText("");
}
}if(accion.getSource()== botonDivision){
if(!campoDeTexto.getText().equals("")){
signo = "/";
memoria1 = campoDeTexto.getText();
campoDeTexto.setText("");
}
}
if(accion.getSource()== botonMultiplicacion){
if(!campoDeTexto.getText().equals("")){
signo = "*";
memoria1 = campoDeTexto.getText();
campoDeTexto.setText("");
}
}
if(accion.getSource()== botonIgual)
{
memoria2 = campoDeTexto.getText();
if(!memoria2.equals(""))
{
calculadora(memoria1, memoria2, signo);
}
}
}


public void calculadora(String memoria1, String memoria2, String signo)
{
double resultado = 0.0;
String respuesta;

if(signo.equals("+")){
resultado=Double.parseDouble(memoria1)+Double.parseDouble(memoria2);
}
if(signo.equals("-")){
resultado=Double.parseDouble(memoria1)-Double.parseDouble(memoria2);
}
if(signo.equals("/")){
resultado=Double.parseDouble(memoria1)/Double.parseDouble(memoria2);
}
if(signo.equals("*")){
resultado=Double.parseDouble(memoria1)*Double.parseDouble(memoria2);
}
respuesta = Double.toString(resultado);
campoDeTexto.setText(respuesta);
}

public static void main(String args[]){

CASIO30 calculadora = new CASIO30();
calculadora.setBounds(400, 400, 300, 350);
calculadora.setVisible(true);
}
}



